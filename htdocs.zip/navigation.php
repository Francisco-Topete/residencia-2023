<?php
echo "<nav>";
echo "<div class=\"navbar\">";
echo "<div class=\"container nav-container\">";
echo "<input class=\"checkbox\" type=\"checkbox\" name=\"\" id=\"\" />";
echo "<div class=\"hamburger-lines\">";
echo "<span class=\"line line1\"></span>";
echo "<span class=\"line line2\"></span>";
echo "<span class=\"line line3\"></span>";
echo "</div>";  
echo "<div class=\"logo\">";
echo "<h1>Mapa</h1>";
echo "</div>";
echo "<div class=\"menu-items\">";
echo "<li><a href=\"admin/rescatistas\">Administrar rescatistas/moderadores</a></li>";
echo "<li><a href=\"admin/nodos\">Administrar nodos</a></li>";
echo "<li><a href=\"admin/cerrarsesion\">Cerrar sesion</a></li>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</nav>";
?>